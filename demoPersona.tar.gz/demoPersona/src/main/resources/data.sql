insert into persona(id,nombre,apellido,direccion,telefono,clave) values('1','Jack','Rodriguez','direccion1','0998523610','1234');
insert into persona(id,nombre,apellido,direccion,telefono,clave) values('2','Fernado','Martinez','direccion2','0998523615','1234');
insert into persona(id,nombre,apellido,direccion,telefono,clave) values('3','Javier','Pineda','direccion3','0998523614','1234');
insert into persona(id,nombre,apellido,direccion,telefono,clave) values('4','Erika','Pintado','direccion4','0998523613','1234');


  
