
CREATE TABLE persona
(
 id varchar(2) NOT NULL,
  nombre varchar(50) NOT NULL ,
 apellido varchar(50) NOT NULL,
 direccion varchar(100) NOT NULL,
 telefono varchar(10) NOT NULL,
 clave varchar(50)NOT NULL,
 PRIMARY KEY (id)
);
