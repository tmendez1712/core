package com.example.demo.services;

import java.util.List;

import com.example.demo.entity.Persona;
import com.example.demo.model.RepuestaLogin;

public interface IPersonaServices {
	List<Persona> findAll();

	void insertPersona(Persona per);

	void updatePersona(Persona per);

	void executeUpdatePersona(Persona per);

	void deletePersona(Persona per);
	
	public RepuestaLogin login(String nom, String pass);
	
	public RepuestaLogin validateUser(String nom, String pass);


	

}
