package com.example.demo.controller;

import java.util.List;

import javax.annotation.Resource;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Persona;
import com.example.demo.model.RepuestaLogin;
import com.example.demo.services.IPersonaServices;
import com.example.demo.services.PersonaServicesImpl;




@RestController
@RequestMapping("/personaApp")
public class PersonaController {
	
	private Integer codigo = 1;
	private String respuesta = "OK";
	private Boolean estado = true;

	@Resource 
	IPersonaServices personaService;
	PersonaServicesImpl perServiceImp;
	
	@GetMapping(value = "/personaList")
	public List<Persona> getPersonas() {
		return personaService.findAll();
	
	}
	@PostMapping(value = "/createPer")
	public void createPersona(@RequestBody Persona per) {
		 personaService.insertPersona(per);
	
	}
	
	@PutMapping(value = "/updatePer")
	public void updatePersona(@RequestBody Persona per) {
		 personaService.updatePersona(per);
	
	}
	@PutMapping(value = "/executeUpdatePer")
	public void executeUpdatePersona(@RequestBody Persona per) {
		 personaService.executeUpdatePersona(per);
	}
	
	@DeleteMapping(value = "/deletePerById")
	public void deletePersona(@RequestBody Persona per) {
		 personaService.deletePersona(per);
	
	}
	
	@CrossOrigin(origins = "*")
	@GetMapping(value = "/login")
	public RepuestaLogin login(@RequestParam String nom, @RequestParam String pass) {
		return personaService.login(nom, pass);
		
	}
	
	
	
	
}
