package com.example.demo.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.example.demo.entity.Persona;;
public class PersonaRowMapper implements RowMapper<Persona> {

	@Override
	public Persona mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Persona per =new Persona();
		per.setId(rs.getString("id"));
		per.setNombre   (rs.getString("nombre"));
		per.setApellido (rs.getString("apellido"));
		per.setDireccion(rs.getString("direccion"));
		per.setTelefono (rs.getString("telefono"));
		per.setClave    (rs.getString("clave"));
		
		return per;
	}

}
