package com.example.demo.dao;

import java.util.List;

import com.example.demo.entity.Persona;
import com.example.demo.model.RepuestaLogin;

public interface IPersonaDao {

	List<Persona> findAll();
	void insertPersona(Persona per);

	void updatePersona(Persona per);

	void executeUpdatePersona(Persona per);

	public void deletePersona(Persona per);
	
    public RepuestaLogin login(String nom, String pass);
	
	public RepuestaLogin validateUser(String nom, String pass);
}
