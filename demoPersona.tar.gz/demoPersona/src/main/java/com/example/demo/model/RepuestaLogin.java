package com.example.demo.model;

import com.example.demo.entity.Persona;

public class RepuestaLogin {
	
	private int codigo;
	private String respuesta;
	private boolean estado;
	private Persona persona;
	
	public RepuestaLogin(int codigo, String respuesta, boolean estado, Persona persona) {
		super();
		this.codigo = codigo;
		this.respuesta = respuesta;
		this.estado = estado;
		this.persona = persona;
	}
	public RepuestaLogin(int codigo, String respuesta, boolean estado) {
		super();
		this.codigo = codigo;
		this.respuesta = respuesta;
		this.estado = estado;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getRespuesta() {
		return respuesta;
	}
	public void setRespuesta(String respuesta) {
		this.respuesta = respuesta;
	}
	public boolean isEstado() {
		return estado;
	}
	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	public Persona getPersona() {
		return persona;
	}
	public void setPersona(Persona persona) {
		this.persona = persona;
	}
	
	
	

}
