package com.example.demo.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import com.example.demo.dao.IPersonaDao;
import com.example.demo.entity.Persona;
import com.example.demo.model.RepuestaLogin;
import com.example.demo.services.IPersonaServices;


@Component
public class PersonaServicesImpl implements IPersonaServices {

	private Integer codigo = 1;
	private String respuesta = "OK";
	private Boolean estado = true;
	
	@Resource 
	IPersonaDao personaDao;

	@Override
	public List<Persona> findAll() {
		// TODO Auto-generated method stub
		return personaDao.findAll();
	}

	@Override
	public void insertPersona(Persona per) {
		// TODO Auto-generated method stub
		personaDao.insertPersona(per);
		
	}

	@Override
	public void updatePersona(Persona per) {
		// TODO Auto-generated method stub
		personaDao.updatePersona(per);
		
	}

	@Override
	public void executeUpdatePersona(Persona per) {
		// TODO Auto-generated method stub
		personaDao.executeUpdatePersona(per);
		
	}

	@Override
	public void deletePersona(Persona per) {
		// TODO Auto-generated method stub
		personaDao.deletePersona(per);
	}
	
	

	@Override
	public RepuestaLogin login(String nom, String pass) {
		return personaDao.login(nom, pass);
	}

	@Override
	public RepuestaLogin validateUser(String nom, String pass) {
		// TODO Auto-generated method stub
		return personaDao.validateUser(nom, pass);
	}

	
}
