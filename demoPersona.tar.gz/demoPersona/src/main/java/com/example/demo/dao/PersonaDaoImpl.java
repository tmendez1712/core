package com.example.demo.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Persona;
import com.example.demo.mapper.PersonaRowMapper;
import com.example.demo.model.RepuestaLogin;




@Repository
public class PersonaDaoImpl implements IPersonaDao {
	private static final Logger logger = LoggerFactory.getLogger(PersonaDaoImpl.class);
	
	private Integer codigo = 1;
	private String respuesta = "OK";
	private Boolean estado = true;
	


	public PersonaDaoImpl(NamedParameterJdbcTemplate template) {  
        this.template = template;  
	}  
	NamedParameterJdbcTemplate template;  
	
	/**
	 * Recupera todos los datos de PErsona y luego asigna el conjunto de
	 * resultados a un Objeto de persona utilizando RowMapper
	 */
	@Override
	public List<Persona> findAll() {
		// TODO Auto-generated method stub
		return template.query("select * from persona", new PersonaRowMapper());
	}
	
	/**
	 * Insertará una persona usando template.update (sql, param, holder)
	 * donde param es SqlParameterSource, que asignará los valores dinámicamente 
	 * en la consulta marcada con dos puntos. 
	 * GeneratedKeyHolder devolverá un valor generado automáticamente cuando se inserten los datos.
	 */

	@Override
	public void insertPersona(Persona per) {
		// TODO Auto-generated method stub
		final String sql = "insert into persona(id,nombre,apellido,direccion,telefono,clave)"
						 + "values(:id,:nombre,:apellido,:direccion,:telefono,:clave)";
		
		 KeyHolder holder = new GeneratedKeyHolder();
	        SqlParameterSource param = new MapSqlParameterSource()
					.addValue("id", 	  per.getId())
					.addValue("nombre",   per.getNombre())
					.addValue("apellido", per.getApellido())
					.addValue("direccion",per.getDireccion())
					.addValue("telefono", per.getTelefono())
					.addValue("clave",    per.getClave());
	        template.update(sql,param, holder);
		
	}

	@Override
	public void updatePersona(Persona per) {
		// TODO Auto-generated method stub
		
		final String sql = "update persona set nombre=:nombre, apellido=:apellido, direccion=:direccion, telefono=:telefono, clave=:clave"
						 + " where id=:id";
		 
        KeyHolder holder = new GeneratedKeyHolder();
        SqlParameterSource param = new MapSqlParameterSource()
        		.addValue("id", 	  per.getId())
				.addValue("nombre",   per.getNombre())
				.addValue("apellido", per.getApellido())
				.addValue("direccion",per.getDireccion())
				.addValue("telefono", per.getTelefono())
				.addValue("clave",    per.getClave());
        template.update(sql,param, holder);
		
	}
	/**
	 * Actualizará una persona usando template.execute
	 */
	@Override
	public void executeUpdatePersona(Persona per) {
		// TODO Auto-generated method stub
		 final String sql = "update persona set nombre=:nombre, apellido=:apellido, direccion=:direccion, telefono=:telefono, clave=:clave"
		 				 + " where id=:id";
		 

		 Map<String,Object> map=new HashMap<String,Object>();  
		 map.put("id", 	  per.getId());
		 map.put("nombre",   per.getNombre());
		 map.put("apellido", per.getApellido());
		 map.put("direccion",per.getDireccion());
		 map.put("telefono", per.getTelefono());
		 map.put("clave",    per.getClave());
	
		 template.execute(sql,map,new PreparedStatementCallback<Object>() {  
			    @Override  
			    public Object doInPreparedStatement(PreparedStatement ps)  
			            throws SQLException, DataAccessException {  
			        return ps.executeUpdate();  
			    }  
			});  
		
	}
	/**
	 * Eliminara una persona segun el ID
	 */
	@Override
	public void deletePersona(Persona per) {
		// TODO Auto-generated method stub
		
		final String sql = "delete from persona where id=:id";
		 

		 Map<String,Object> map=new HashMap<String,Object>();  
		 map.put("id", per.getId());
	
		 template.execute(sql,map,new PreparedStatementCallback<Object>() {  
			    @Override  
			    public Object doInPreparedStatement(PreparedStatement ps)  
			            throws SQLException, DataAccessException {  
			        return ps.executeUpdate();  
			    }  
			});  
		
	}
	
	/**
	 * Recupera datos de una persona
	 */
	public Persona findpersona(String nombre) {
		// TODO Auto-generated method stub
		return template.queryForObject("select * from persona where nombre = :nombre",new MapSqlParameterSource(
		           "nombre", nombre), new PersonaRowMapper());
	}
	/**
	 * Metodo Login
	 */
	@Override
	public RepuestaLogin login(String nom, String pass) {
		// TODO Auto-generated method stub
		logger.info("login(nom:{};pass:{}",nom,pass);
		RepuestaLogin result = validateUser(nom, pass);
		
		if (result.getRespuesta().equals("OK")) {
			Persona objUser= findpersona(nom);
			if(objUser!=null) {
				if(objUser.getClave().compareTo(pass)==0) {
					return new RepuestaLogin(codigo, respuesta, true,objUser);
				}
				else {
					logger.error("NOMBRE NO EXISTE USER: {} PASSWORD INCORRECTO: {}", nom,pass);
					return new RepuestaLogin(0, "PASSWORD INCORRECTO", false);	
				}				
			}else {
				logger.error("NOMBRE NO EXISTE USER: {}", nom);
				return new RepuestaLogin(0, "USUARIO NO EXISTE", false);	
			}
			
		} else {
			logger.error(result.getRespuesta());
			return result;
		}
	}
	/**
	 * Metodo valida existe o no el nombre de la persona
	 */
	@Override
	public RepuestaLogin validateUser(String nom, String pass) {
		// TODO Auto-generated method stub
		if (nom==null || nom.isEmpty()) {
			logger.info("No se ingreso usuario");
			return new RepuestaLogin(0, "INGRESE EL NOMBRE", false);
		}

		if (pass==null || pass.isEmpty()) {
			logger.info("No se ingreso password");
			return new RepuestaLogin(0, "INGRESE LA CONTRASEÑA", false);
		}

		return new RepuestaLogin(codigo, respuesta, estado);
	}

}
